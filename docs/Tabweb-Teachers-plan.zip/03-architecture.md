# المعمارية متعددة المستأجرين وقابلية التوسع

**قرار الأساس:** Modular Monolith على Express/TypeScript الحالي وMySQL، مع عمال خلفية منفصلين عند النشر. لا microservices ولا multi-region writes في MVP. راجعوا [تقرير التدقيق](ARCHITECTURE_AUDIT_AND_MIGRATION_PLAN_AR.md) و[شريحة SaaS المنفذة جزئيًا](SAAS_SLICE_ROLLOUT_AR.md): النموذج المستهدف ليس وصفًا كاملاً للحالة المنشورة.

## الحدود والوحدات

وحدات API داخل التطبيق: `identity`, `tenants`, `catalog`, `enrollment`, `learning`, `assessment`, `billing`, `media`, `notifications`, `analytics`, `platform-admin`, `audit`. REST هو عقد المنتج؛ Socket.IO للتنبيهات والحضور النصي فقط. اجعلوا API والـworker قابلين للنشر منفصلين من نفس المستودع. لا تُنشأ خدمة مستقلة حتى يظهر ضغط حمل أو ملكية فريق مستقلة.

```mermaid
flowchart LR
  Web[React Web / PWA] --> Edge[DNS + WAF + CDN]
  Edge --> API[Express API]
  API --> DB[(MySQL)]
  API --> Cache[(Redis / Queue)]
  Worker[Workers] --> Cache
  Worker --> DB
  API -.->|V1 بعد العقد: checkout| Pay[بوابة دفع الطلاب]
  Pay -.->|V1: webhook متحقق| API
  API --> Video[Video Provider]
  Web -->|Direct upload / playback| Video
  API --> Obs[Logs / Metrics / Traces]
  Worker --> Obs
```

## نموذج tenancy

- الحساب `User` عالمي، والانضمام إلى مؤسسة عبر `Membership(tenant_id,user_id,role,status)`.
- كل مورد تعليمي يحمل tenant_id صريحًا؛ لا نكتفي بعلاقة أب لتجنب استعلامات scope المنسية. لروابط `course_id`, `student_id` نستخدم مفاتيح مركبة `(tenant_id,id)` وFK مركب.
- معرف tenant الفعال يشتق من عضوية مستخدم مصادق عليها أو نطاق مُتحقق من ربطه؛ لا يعتبر معرف العميل تفويضًا.
- وظائف platform admin العابرة للمؤسسات تحتاج صلاحية صريحة وسببًا وسجل تدقيق. دعم المنصة لا يحصل على wildcard دائم.
- نطاقات cache وjobs وobject keys تتضمن tenant ID؛ يجب ألا تعيد cache إجابة tenant آخر.
- ترحيل البيانات: جرد global/tenant-scoped، backfill متحقق، عزل الصفوف الغامضة، إضافة FK/index، ثم فرض scope على المسارات قبل فتح التسجيل العام.

## ERD مختصر مستهدف (يتضمن نماذج V1)

```mermaid
erDiagram
  TENANT ||--o{ MEMBERSHIP : has
  USER ||--o{ MEMBERSHIP : joins
  TENANT ||--o{ COURSE : owns
  COURSE ||--o{ LESSON : contains
  COURSE ||--o{ ENROLLMENT : admits
  USER ||--o{ ENROLLMENT : studies
  TENANT ||--o{ GROUP : owns
  GROUP ||--o{ GROUP_MEMBERSHIP : includes
  LESSON ||--o{ MEDIA_ASSET : references
  COURSE ||--o{ EXAM : assesses
  EXAM ||--o{ ATTEMPT : receives
  USER ||--o{ ATTEMPT : submits
  COURSE ||--o{ COURSE_ORDER : sells
  COURSE_ORDER ||--o{ STUDENT_PAYMENT_ATTEMPT : records
  TENANT ||--o{ PLATFORM_SUBSCRIPTION : subscribes
  PLATFORM_SUBSCRIPTION ||--o{ PLATFORM_CHARGE : billed_by
  TENANT ||--o{ AUDIT_EVENT : records
  TENANT ||--o{ DOMAIN : configures
```

## DDL مرجعي (MySQL/InnoDB)

هذا نموذج تنفيذ مستهدف، لا migration جاهزة على قاعدة الإنتاج. طابقوا أنواع المفاتيح مع الـschema الفعلي قبل استعماله.

```sql
CREATE TABLE tenants (
  id BINARY(16) PRIMARY KEY,
  slug VARCHAR(63) NOT NULL UNIQUE,
  display_name VARCHAR(160) NOT NULL,
  status VARCHAR(20) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE memberships (
  tenant_id BINARY(16) NOT NULL,
  user_id BINARY(16) NOT NULL,
  role VARCHAR(32) NOT NULL,
  status VARCHAR(16) NOT NULL,
  PRIMARY KEY (tenant_id, user_id),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE courses (
  tenant_id BINARY(16) NOT NULL,
  id BINARY(16) NOT NULL,
  title VARCHAR(255) NOT NULL,
  status VARCHAR(24) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (tenant_id, id),
  INDEX idx_course_status (tenant_id, status)
);

CREATE TABLE enrollments (
  tenant_id BINARY(16) NOT NULL,
  id BINARY(16) NOT NULL,
  course_id BINARY(16) NOT NULL,
  student_id BINARY(16) NOT NULL,
  status VARCHAR(24) NOT NULL,
  PRIMARY KEY (tenant_id, id),
  UNIQUE KEY uq_enrollment_student_course (tenant_id, course_id, student_id),
  FOREIGN KEY (tenant_id, course_id) REFERENCES courses(tenant_id, id),
  FOREIGN KEY (tenant_id, student_id) REFERENCES memberships(tenant_id, user_id)
);
```

طبّقوا النمط على `lessons`, `groups`, `media_assets`, `payments`, `attempts` و`audit_events`. إذا كان الطالب قد يسبق membership، يُنشأ سجل عضوية pending موثق قبل enrollment.

### فصل السجلات المالية

لا تستخدموا جدول `payments` واحدًا لاشتراك SaaS ومدفوعات الدورات. نموذج المجال المستهدف يفصل `platform_subscriptions/platform_charges` (tenant يدفع لـTabweb) عن `course_orders/student_payment_attempts` (طالب يدفع للمدرس). MVP لا يدمج مدفوعات الطالب: يحتفظ فقط بمرجع خارجي وحالة مراجعة يدوية، ولا يسجلها كتحصيل من Tabweb أو تسوية مثبتة. لا تُضاف `payouts` قبل عقد marketplace وقواعد KYC والتسوية/النزاعات.

## API والعقود

أمثلة مستهدفة لـREST versioned؛ أسماء المسارات تتكيف مع النسخة الحالية وتهاجر عبر compatibility adapter. في MVP لا يوجد student checkout ولا payment webhook داخل Tabweb؛ يحتفظ المنتج بمرجع خارجي وحالة مراجعة المدرس. نقاط الدفع أدناه V1 بعد contract وإثبات acquiring/settlement:

| Endpoint | المرحلة | الغرض / الشرط الأساسي |
|---|---|---|
| `POST /v1/tenants` | MVP (admin-assisted) | إنشاء مؤسسة؛ إدارة مخولة وidempotency |
| `POST /v1/courses` | MVP | إنشاء دورة؛ `course.create` وtenant من principal |
| `POST /v1/enrollments` | MVP | تسجيل طالب؛ تحقق course/tenant والاستحقاق اليدوي |
| `POST /v1/media/uploads` | MVP (حسب تكامل VdoCipher القائم) | بدء رفع؛ حصة ومالك ونوع/حجم؛ رابط محدود العمر |
| `POST /v1/media/:id/playback-token` | MVP (تحقق في staging) | منح تشغيل؛ enrollment/access ووقت إتاحة الدرس |
| `POST /v1/payments/checkout` | V1 بعد العقد | إنشاء checkout للمدرس؛ merchant account/mبلغ/عملة/idempotency |
| `POST /v1/webhooks/:provider` | V1 للدفع؛ provider callback للفيديو حسب التكامل | تحقق توقيع، idempotency، مبلغ/مرجع/مصدر قبل تحديث حالة الدفع |
| `GET /v1/student/progress` | MVP | تقدم الطالب؛ الهوية من الجلسة فقط |

انشروا OpenAPI للعقود، استخدموا state machines للمدفوعات والاشتراكات، واحتفظوا بـrequest ID ومفتاح idempotency للعمليات القابلة للتكرار. لا تسجلوا الأسرار أو payload حساسًا كاملًا.

## الطوابير والكاش

Redis + BullMQ خيار بعد تثبيت احتياج العامل المنفصل: بريد/واتساب، تقارير، تحديث تحليلات، مهام وسيط الفيديو، وإعادة محاولة webhook. كل job يحمل `tenant_id`, actor/resource IDs ومفتاح idempotency؛ يعيد التحقق من الاستحقاق عند التنفيذ. حدود concurrency وqueue لكل tenant تمنع حجب بقية المؤسسات. كاش قصير لبيانات الكتالوج/الإعداد العام فقط مع tenant key؛ لا تخزن authorization decision طويلًا.

## التخزين والحافة والمناطق

MySQL كتابة في منطقة واحدة أولًا. CDN/WAF يقدم الواجهة والأصول العامة؛ مزود الفيديو يقدم الفيديو، وobject store للملفات العامة/الخاصة. API لا يمرر stream. ابدأوا بالنسخ الاحتياطي واستعادة فعلية، ثم read replica للقراءات الثقيلة بناءً على metrics. لا multi-region writes في البداية؛ replica إقليمية/DR لاحقًا بعد قياس زمن القراءة ومتطلبات residency. حدّدوا RPO/RTO بالعقد قبل تفعيل DR.

## خطة التوسع

| مستوى | التغيير التشغيلي | متى؟ |
|---|---|---|
| Pilot–100 مدرس | API بسيط، قاعدة managed صغيرة، worker واحد/اثنان، queue وmetrics، CDN خارجي | فورًا بعد بوابة الأمن |
| 1,000 مدرس | API replicas، توسعة DB/Redis والعمال، read replica عند ضغط القراءة، tenant quotas | عند CPU/connection/latency saturation المقاسة |
| 10,000 مدرس | فصل قراءة analytics، queue partitions/priority، autoscaling workers، مراجعة shard أو DB per large tenant | بعد حمل فعلي ومؤشرات p95 وstorage، لا بالعدد الاسمي وحده |

لا تضيفوا Kubernetes مبكرًا. حاويات Docker أو PaaS تخدم فريقًا صغيرًا حتى يصبح التحكم في النشر عائقًا مثبتًا.

## تقدير تكلفة تشغيل شهري

بالدولار، **تقديري غير ملزم دون الفيديو والرواتب والرسائل وبوابات الدفع والضرائب**. يفترض Railway Pro للـAPI/worker (الحد المنشور $20 ويتضمن $20 استخدامًا؛ الموارد الإضافية حسب CPU/RAM/egress)، قاعدة MySQL مُدارة، Redis، نسخ ومراقبة وCDN. DigitalOcean يذكر managed DB تبدأ من $15، لكن MySQL الفعلية تعتمد على الحجم والمنطقة والتوافر. أسعار المصادر عند التحقق 9 أكتوبر 2026.

| المدرسون | حمل افتراضي: طلاب مسجلون / نشطون يوميًا / ذروة قصيرة | بنية التطبيق والبيانات دون فيديو |
|---:|---|---:|
| 100 | 5,000 / 500 / ~200؛ API صغير و1–2 worker وقاعدة صغيرة | $250–$600 / شهر |
| 1,000 | 50,000 / 5,000 / ~1,500؛ عدة replicas/عمال وقاعدة وcache أكبر | $900–$2,500 / شهر |
| 10,000 | 500,000 / 50,000 / ~15,000؛ توسع أفقي وقاعدة/قراءة منفصلة | $4,000–$12,000 / شهر |

هذه نطاقات تخطيط وليست budget موثوقًا قبل اختبار حمل وعرض سعر؛ الأرقام تفترض استهلاك API وDB غير الفيديو ولا ضمان توافر عالٍ متعدد المناطق. قيسوا p95، قاعدة البيانات، queue والسجلات لتعديلها. للمقارنة على سعر Cloudflare Stream المنشور، افترضوا لكل مدرس 50 طالبًا نشطًا × 6 ساعات مشاهدة شهريًا، و20 ساعة محتوى محفوظة: $18/مدرس للتسليم + $6/مدرس للتخزين. بذلك يكون النموذج التقريبي:

| المدرسون | بنية دون فيديو | فيديو على افتراض Cloudflare Stream | الإجمالي النموذجي |
|---:|---:|---:|---:|
| 100 | $250–$600 | ~$2,400 | ~$2,650–$3,000 |
| 1,000 | $900–$2,500 | ~$24,000 | ~$24,900–$26,500 |
| 10,000 | $4,000–$12,000 | ~$240,000 | ~$244,000–$252,000 |

هذا **حساب حساسية للمقارنة، وليس توصية شراء Cloudflare Stream**: يوضح لماذا ينبغي تحديد حدود مشاهدة وخطة فيديو مدفوعة وتفضيل عروض VdoCipher/Bunny بعد pilot. لا يشمل الدعم والضرائب وe-mail/SMS أو بوابات الدفع. ضعوا إنذار تكلفة وbudget cap لكل tenant. [Railway pricing](https://docs.railway.com/pricing/plans) · [DigitalOcean managed databases](https://www.digitalocean.com/resources/articles/aws-rds-vs-digitalocean-managed-databases) · [Cloudflare Stream pricing](https://developers.cloudflare.com/stream/pricing/) · [R2 pricing](https://developers.cloudflare.com/r2/pricing/).

## قرارات الجولة الثالثة

| القرار | البدائل المرفوضة | لماذا |
|---|---|---|
| Modular monolith + MySQL مشتركة بمفاتيح مركبة ونطاق مركزي | إعادة كتابة إلى microservices وDB منفصل لكل مدرس | وقت أقل ومخاطر ترحيل أقل مع فريق صغير؛ فصل لاحق مع دليل. |
| Redis/worker منفصل للمهام الثقيلة | تنفيذ الفيديو والبريد داخل API request | يحسن إعادة المحاولة والعزل والضغط العكسي. |
| منطقة كتابة واحدة وCDN | multi-region writes مبكرًا | يقلل تعقيد الاتساق والتعافي؛ يراجع بعد قياس التأخير. |

## نقد متقاطع

- **إلى المنتج:** custom domain لكل مدرس في MVP يضيف DNS verification وTLS ودعم takeover؛ subdomain أولًا.
- **إلى UX:** DRM إلزامي لكل خطة يضيف كلفة دعم توافق؛ ابدأوا بمستوى حماية معلن واختبروا الحاجة قبل رفع التغطية.
