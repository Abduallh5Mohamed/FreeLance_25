# المكدس التقني النهائي

## القرار المختصر

| الطبقة | الاختيار | السبب/Trade-off |
|---|---|---|
| واجهة | React 18 + Vite + TypeScript الحالي | استمرار البناء الحالي، تصميم عربي RTL responsive؛ لا rewrite دون عائق مثبت. |
| API | Express 4 + TypeScript الحالي كـmodular monolith وREST versioned | إعادة استخدام الشيفرة مع وحدات داخلية وحدود API واضحة. |
| البيانات | MySQL/InnoDB الحالي مع migrations إضافية | يحافظ على بيانات وتكاملات موجودة؛ يلزم tenant-aware keys وbackfill آمن. |
| Cache/queue | Redis + BullMQ عند فصل worker | إعادة محاولة للرسائل والتقارير والمهام؛ Redis socket adapter عند تعدد replicas. |
| Real-time | Socket.IO الحالي للتنبيهات والحضور | ليس لنقل الصوت أو الفيديو؛ مصادقة handshake مطلوبة. |
| Video | VdoCipher الموجود للأصول التي تتطلب DRM؛ provider adapter لتقييم HLS managed | لا نعيد بناء الحماية الموجودة، ولا نفترض تغطية كل فيديو؛ راجع [web-drm-setup](web-drm-setup.md). |
| ملفات عادية | MinIO الموجود للتوافق/التطوير، ثم S3-compatible أو R2 وفق التكلفة والخصوصية | فصل ملفات PDF عن الفيديو؛ R2 يعلن egress مجانيًا، لكن العمليات مدفوعة. |
| Live | Zoom Meeting link في MVP؛ LiveKit Cloud أو Zoom Video SDK بعد إثبات الحاجة | لا بناء SFU داخلي. |
| نشر | Docker للحاويات؛ Railway Pro كخيار إطلاق سريع أو مزود متوافق مع استضافة DB managed منفصلة | يقلل ops للفريق؛ حد Railway المنشور $20 يتضمن $20 من الاستخدام ثم موارد حسب الاستهلاك. |
| حافة | Cloudflare DNS/WAF/CDN للأصول والواجهة، CDN المزود للفيديو | لا proxy الفيديو عبر API؛ قواعد حماية وحدود. |
| جوال | Responsive web/PWA؛ React Native/Expo بعد ثبوت طلب التطبيق | يقلل سطح العمل خلال pilot. |
| CI/CD ومراقبة | GitHub Actions، migrations مع review gate، Sentry وmetrics/logs/traces | نشر قابل للتراجع ومراقبة أخطاء وqueue وDB وwebhooks. |

## ممارسات ملزمة

- لا تغيّروا MySQL إلى PostgreSQL الآن؛ إعادة كتابة قاعدة لا تعالج auth/tenant bugs بحد ذاتها.
- أسرار كل بيئة في secret manager؛ مفاتيح playback/webhook لا تذهب إلى bundle الواجهة.
- tenant scope في server policy/repository، لا في React وحده.
- نطاقات فرعية أولًا؛ custom domains بعد التحقق من DNS والملكية وTLS وsupport lifecycle.
- نقل Railway إلى AWS ECS/Fargate أو مزود حاويات مُدار عند الحاجة المقاسة للسيطرة؛ لا Kubernetes افتراضيًا.

## مصادر السعر المحدثة

- [Railway pricing](https://docs.railway.com/pricing/plans): Pro حد أدنى معلن $20 شهريًا مع $20 usage credit؛ CPU/RAM/egress حسب الاستهلاك.
- [DigitalOcean managed DB comparison](https://www.digitalocean.com/resources/articles/aws-rds-vs-digitalocean-managed-databases): بداية السعر المنشورة $15، والسعر الفعلي يتغير حسب حجم MySQL والمنطقة.
- [Cloudflare R2](https://developers.cloudflare.com/r2/pricing/): تخزين وعمليات حسب الاستخدام، egress للإنترنت مجاني وفق الصفحة.
- [Cloudflare Stream](https://developers.cloudflare.com/stream/pricing/) و[Bunny Stream](https://bunny.net/pricing/stream/): تكلفة الفيديو منفصلة عن بنية التطبيق.

## النقد المتقاطع

- **إلى المنتج:** custom domains في MVP يوسع DNS verification وTLS ودعم أخذ النطاق؛ ابدأوا subdomain ثم أضيفوا المخصص بعد استقرار دورة التشغيل.
- **إلى UX:** DRM إلزامي على كل مدرس يرفع عبء دعم التوافق؛ ابدأوا بمستوى الحماية المناسب للقيمة وأضيفوا DRM لخطة أعلى بعد إثبات الطلب والتكلفة.
