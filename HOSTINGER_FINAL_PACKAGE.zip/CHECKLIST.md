# ✅ Checklist - قبل وبعد الرفع

## قبل الرفع على Hostinger:

### معلومات تحتاجها:
- [ ] اسم النطاق (Domain Name)
- [ ] بيانات تسجيل الدخول لـ Hostinger
- [ ] بيانات SSH (Username & Password)

### ملفات جاهزة:
- [x] hostinger-package.zip (4.89 MB)
- [x] Frontend مبني (dist/)
- [x] Backend مبني (server/dist/)
- [x] Database schemas جاهزة
- [x] Documentation كاملة

---

## أثناء الرفع:

### 1. رفع الملفات:
- [ ] رفعت محتويات public_html
- [ ] رفعت محتويات api
- [ ] تأكدت من وجود .htaccess
- [ ] تأكدت من وجود .env

### 2. قاعدة البيانات:
- [ ] أنشأت MySQL database
- [ ] أنشأت MySQL user
- [ ] ربطت المستخدم بالقاعدة
- [ ] منحت جميع الصلاحيات
- [ ] استوردت mysql-schema.sql
- [ ] استوردت باقي الملفات (إن وُجدت)

### 3. الإعدادات:
- [ ] عدّلت DB_HOST في .env
- [ ] عدّلت DB_USER في .env
- [ ] عدّلت DB_PASSWORD في .env
- [ ] عدّلت DB_NAME في .env
- [ ] غيّرت JWT_SECRET
- [ ] غيّرت SESSION_SECRET

### 4. التثبيت:
- [ ] اتصلت بـ SSH
- [ ] دخلت لمجلد api
- [ ] نفذت: npm install --production
- [ ] انتظرت حتى اكتمل التثبيت
- [ ] تأكدت من وجود node_modules

### 5. التشغيل:
- [ ] شغّلت التطبيق (PM2 أو Node.js Selector)
- [ ] تأكدت من أن الحالة: Running
- [ ] شفت الـ logs ولا فيه أخطاء

---

## بعد الرفع - اختبار كل شيء:

### Frontend:
- [ ] الموقع يفتح: https://yourdomain.com
- [ ] لا توجد أخطاء في Console (F12)
- [ ] الصور ظاهرة بشكل صحيح
- [ ] الـ styling يعمل
- [ ] Navigation يعمل (الانتقال بين الصفحات)
- [ ] React Router يعمل (F5 على أي صفحة)

### API:
- [ ] API يرد: https://yourdomain.com/api/health
- [ ] لا توجد أخطاء في logs
- [ ] الاتصال بقاعدة البيانات يعمل

### تسجيل الدخول:
- [ ] صفحة تسجيل الدخول تظهر
- [ ] أقدر أسجل دخول بالبيانات الافتراضية
  - Phone: 01024083057
  - Password: Mtd#mora55
- [ ] أدخل للوحة التحكم بنجاح
- [ ] البيانات تظهر صح

### الوظائف الأساسية:
- [ ] إنشاء محاضرة جديدة
- [ ] إنشاء مجموعة جديدة
- [ ] رفع ملف
- [ ] عرض الطلاب
- [ ] تسجيل حضور

### الأمان:
- [ ] SSL مفعّل (القفل الأخضر في المتصفح)
- [ ] Force HTTPS يعمل
- [ ] غيّرت كلمة المرور الافتراضية
- [ ] أنشأت حساب أدمن جديد
- [ ] حذفت الحساب التجريبي

---

## إعدادات إضافية موصى بها:

### Performance:
- [ ] فعّلت CDN
- [ ] فعّلت Caching
- [ ] ضغطت الصور الكبيرة

### Security:
- [ ] فعّلت Web Application Firewall
- [ ] فعّلت DDoS Protection
- [ ] خفيت معلومات WHOIS

### Backup:
- [ ] فعّلت Automatic Backup
- [ ] عملت أول backup يدوي
- [ ] حفظت نسخة من قاعدة البيانات عندي

### Monitoring:
- [ ] فعّلت Uptime Monitoring
- [ ] ضبطت Email Alerts
- [ ] سجّلت في Google Analytics (اختياري)

---

## 📝 ملاحظات مهمة:

### موارد الاستضافة:
```
✅ Storage: 50 GB
✅ Bandwidth: Unlimited
✅ Databases: 300
✅ Subdomains: 100
✅ MySQL Connections: 75
✅ Inodes: 600,000
✅ Monthly Visits: ~100,000
```

### حدود يجب مراعاتها:
- PHP Workers: 60
- لا تتخطى 600,000 ملف (inodes)
- راقب استخدام CPU

### جهات اتصال الدعم:
- Hostinger Support: 24/7 Live Chat
- لو في مشكلة: اجمع الـ logs وابعتها للدعم

---

## ❌ مشاكل شائعة وحلولها:

### ❌ موقع لا يفتح:
```
1. تأكد من DNS settings
2. انتظر حتى 48 ساعة للـ propagation
3. تأكد من SSL
4. امسح cache المتصفح
```

### ❌ API Error 500:
```
1. شوف logs: pm2 logs
2. تأكد من .env
3. تأكد من database connection
4. أعد تشغيل: pm2 restart api
```

### ❌ Database connection failed:
```
1. راجع DB credentials في .env
2. تأكد من user permissions
3. جرّب الاتصال من phpMyAdmin
4. تأكد من DB_HOST = localhost
```

### ❌ صفحة بيضاء:
```
1. افتح Console (F12)
2. شوف الأخطاء
3. تأكد من .htaccess
4. تأكد من file permissions
```

---

## 🎉 كل شيء تمام!

إذا كل الـ checkboxes محددة، معناها:

✅ المشروع شغال 100%
✅ جاهز للاستخدام
✅ آمن ومحمي
✅ Performance ممتاز

---

## 📞 معلومات مهمة للحفظ:

```
Database Name: _________________
Database User: _________________
Database Password: _________________

Domain: _________________
SSH Username: _________________
SSH Password: _________________

Admin Phone (New): _________________
Admin Password (New): _________________
```

---

**تاريخ النشر**: ___/___/_____
**اكتمل التثبيت**: ___/___/_____
**آخر اختبار**: ___/___/_____

---

✨ **تهانينا! مشروعك على الهواء** ✨
