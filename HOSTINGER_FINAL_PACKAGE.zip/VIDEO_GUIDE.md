# 🎬 خطوات الرفع - فيديو توضيحي نصي

## المشهد 1: التحضير (دقيقة 1)
```
1. افتح ملف: HOSTINGER_FINAL_PACKAGE.zip
2. استخرج المحتويات لمجلد على سطح المكتب
3. ستجد 3 مجلدات:
   - public_html
   - api  
   - database
```

---

## المشهد 2: تسجيل الدخول لـ Hostinger (دقيقة 2-3)
```
1. اذهب إلى: https://hpanel.hostinger.com
2. سجّل دخول بحسابك
3. اختر الموقع الذي تريد الرفع عليه
```

---

## المشهد 3: رفع Frontend (دقيقة 4-7)
```
الشاشة: Hostinger Panel

1. اضغط على "Files" من القائمة
2. اضغط "File Manager"
3. ستفتح نافذة File Manager

4. افتح مجلد "public_html"
5. احذف أي ملفات موجودة (index.html القديم)

6. اضغط "Upload"
7. اسحب جميع الملفات من مجلد public_html المستخرج
   - index.html
   - مجلد assets
   - ملف .htaccess

8. انتظر حتى يكتمل الرفع
   ✅ Progress bar تصل 100%
```

---

## المشهد 4: رفع Backend (دقيقة 8-10)
```
الشاشة: File Manager

1. ارجع للمجلد الرئيسي (اضغط "Home" أو "../")
2. اضغط "New Folder"
3. اكتب الاسم: api
4. افتح مجلد api الجديد

5. اضغط "Upload"
6. اسحب جميع محتويات مجلد api:
   - ملفات .js
   - مجلد routes
   - مجلد models
   - مجلد middleware
   - package.json
   - .env

7. انتظر الرفع
   ✅ جميع الملفات موجودة
```

---

## المشهد 5: إنشاء Database (دقيقة 11-15)
```
الشاشة: Hostinger Panel

1. من القائمة الرئيسية، اضغط "Databases"
2. اضغط "MySQL Databases"

3. في قسم "Create Database":
   - Database Name: freelance_db
   - اضغط "Create"
   
4. احفظ الاسم الكامل:
   مثال: u123456789_freelance

5. في قسم "MySQL Users":
   - Username: freelance_user
   - Password: [كلمة مرور قوية]
   - اضغط "Create User"

6. احفظ:
   - Username الكامل: u123456789_freelance_user
   - Password: [الكلمة اللي حطيتها]

7. في قسم "Add User to Database":
   - اختر المستخدم
   - اختر Database
   - All Privileges ✓
   - اضغط "Add"

✅ Database جاهزة
```

---

## المشهد 6: استيراد Database (دقيقة 16-20)
```
الشاشة: phpMyAdmin

1. من Databases page، اضغط "phpMyAdmin"
2. ستفتح نافذة phpMyAdmin جديدة

3. من القائمة اليسرى، اختر قاعدة البيانات:
   u123456789_freelance

4. اضغط تبويب "Import" أعلى الصفحة

5. اضغط "Choose File"
6. اختر: database/mysql-schema.sql
7. اضغط "Go" أسفل الصفحة
8. انتظر...
   ✅ "Import has been successfully finished"

9. كرر نفس الخطوات للملفات الأخرى (إن وُجدت):
   - insert-grades-groups.sql
   - insert-arabic-data.sql
   - add-admin-user.sql

10. اضغط tab "Structure"
    ✅ ستشاهد جميع الجداول:
    - users
    - grades
    - groups
    - lectures
    - materials
    - attendance
    - etc.
```

---

## المشهد 7: تعديل .env (دقيقة 21-23)
```
الشاشة: File Manager

1. ارجع لـ File Manager
2. اذهب لمجلد api/
3. ابحث عن ملف .env
4. اضغط بالزر الأيمن → "Edit"

5. عدّل الأسطر التالية:

   من:
   DB_USER=your_hostinger_db_user
   DB_PASSWORD=your_hostinger_db_password
   DB_NAME=your_hostinger_db_name

   إلى:
   DB_USER=u123456789_freelance_user
   DB_PASSWORD=كلمة_المرور_اللي_حطيتها
   DB_NAME=u123456789_freelance

6. غيّر أيضاً:
   JWT_SECRET=اي_نص_عشوائي_طويل_هنا
   SESSION_SECRET=نص_عشوائي_آخر_مختلف

7. اضغط "Save Changes"
8. اضغط "Close"

✅ الإعدادات محفوظة
```

---

## المشهد 8: SSH والتثبيت (دقيقة 24-30)
```
الشاشة: Terminal / PuTTY

1. من Hostinger Panel → "Advanced"
2. اضغط "SSH Access"
3. احفظ معلومات الاتصال:
   - Host
   - Username
   - Password (أو SSH Key)

4. افتح Terminal (Windows: PuTTY / Mac: Terminal)
5. اتصل:
   ssh u123456789@yourdomain.com

6. أدخل Password
   ✅ متصل بالسيرفر

7. اذهب لمجلد api:
   cd ~/api

8. شوف الملفات:
   ls
   ✅ تشاهد: index.js, package.json, routes/, etc.

9. ثبّت المكتبات:
   npm install --production

10. انتظر التثبيت (2-5 دقائق)
    - Downloading packages...
    - Installing...
    
11. تأكد من التثبيت:
    ls node_modules
    ✅ تشاهد: express, mysql2, bcryptjs, etc.
```

---

## المشهد 9: تشغيل التطبيق (دقيقة 31-35)
```
الشاشة: Terminal

### الطريقة 1: باستخدام PM2 (موصى بها)

1. ثبّت PM2:
   npm install -g pm2

2. شغّل التطبيق:
   pm2 start index.js --name api

3. تأكد من التشغيل:
   pm2 status
   
   ✅ يجب أن ترى:
   ┌─────┬──────┬─────────┬───────┐
   │ id  │ name │ status  │ cpu   │
   ├─────┼──────┼─────────┼───────┤
   │ 0   │ api  │ online  │ 0%    │
   └─────┴──────┴─────────┴───────┘

4. شاهد الـ logs:
   pm2 logs api
   
   ✅ يجب أن ترى:
   [API] Server running on port 3000
   [API] Database connected successfully

5. احفظ الإعدادات:
   pm2 save
   pm2 startup

---

### الطريقة 2: Node.js Selector

الشاشة: Hostinger Panel

1. من القائمة → "Advanced"
2. ابحث عن "Node.js"
3. اضغط "Create Application"
4. املأ:
   - Node version: 18.x
   - Application mode: Production
   - Application root: api
   - Application startup file: index.js
5. اضغط "Create"
6. انتظر...
   ✅ Status: Running
```

---

## المشهد 10: الاختبار النهائي (دقيقة 36-40)
```
الشاشة: المتصفح

1. افتح: https://yourdomain.com
   ✅ صفحة تسجيل الدخول تظهر

2. اضغط F12 → Console
   ✅ لا توجد أخطاء

3. اختبر API:
   افتح: https://yourdomain.com/api/health
   ✅ ترى: {"status":"ok"}

4. سجّل دخول:
   - الهاتف: 01024083057
   - كلمة المرور: Mtd#mora55
   - اضغط "تسجيل الدخول"

5. ✅ تدخل للوحة التحكم

6. جرّب إنشاء محاضرة:
   - اضغط "المحاضرات"
   - اضغط "إضافة محاضرة"
   - املأ البيانات
   - اضغط "حفظ"
   
   ✅ المحاضرة تُنشأ بنجاح

7. جرّب رفع ملف:
   - اذهب للمحاضرة
   - اضغط "رفع مادة"
   - اختر ملف
   - اضغط "رفع"
   
   ✅ الملف يُرفع بنجاح
```

---

## المشهد 11: الأمان والإعدادات (دقيقة 41-45)
```
الشاشة: Hostinger Panel

1. فعّل SSL:
   - Websites → SSL
   - اختر "Free SSL"
   - Install
   - Force HTTPS: ON
   ✅ القفل الأخضر في المتصفح

2. فعّل Backups:
   - Websites → Backups
   - Auto Backup: Weekly
   - اضغط "Create Backup" (أول نسخة)
   ✅ Backup created

3. فعّل Security:
   - Advanced → Security
   - Web Application Firewall: ON
   - DDoS Protection: ON
   ✅ Protected

4. راقب الموارد:
   - Dashboard → Resources
   - شوف: CPU, RAM, Disk usage
   ✅ كله أخضر
```

---

## المشهد 12: تغيير كلمة المرور (دقيقة 46-50)
```
الشاشة: الموقع

1. سجّل دخول بالحساب الافتراضي
2. اذهب للإعدادات / الملف الشخصي
3. غيّر كلمة المرور:
   - كلمة المرور القديمة: Mtd#mora55
   - كلمة المرور الجديدة: [كلمة قوية]
   - تأكيد: [نفس الكلمة]
4. اضغط "حفظ"
   ✅ تم تغيير كلمة المرور

5. سجّل خروج وسجّل دخول بالكلمة الجديدة
   ✅ تسجيل الدخول ناجح

6. (اختياري) أنشئ حساب أدمن جديد:
   - اذهب للمستخدمين
   - أضف معلم جديد
   - احفظ

7. (اختياري) احذف الحساب التجريبي:
   - 01024083057
   - Delete
```

---

## 🎉 النهاية - كل شيء جاهز!

```
╔═══════════════════════════════════════╗
║                                       ║
║  ✅ DEPLOYMENT SUCCESSFUL!           ║
║                                       ║
║  🌐 Website: https://yourdomain.com  ║
║  🔐 Admin Panel: ✓ Working           ║
║  💾 Database: ✓ Connected            ║
║  🚀 API: ✓ Running                   ║
║  🔒 SSL: ✓ Enabled                   ║
║  📦 Backups: ✓ Configured            ║
║                                       ║
║  Total Time: ~50 minutes             ║
║  Status: LIVE ✨                     ║
║                                       ║
╚═══════════════════════════════════════╝
```

---

## 📝 Checklist سريع

```
□ ملفات مرفوعة (public_html + api)
□ Database منشأة
□ SQL files مستوردة
□ .env معدّل
□ npm install منتهي
□ API شغال (pm2 status)
□ الموقع يفتح
□ تسجيل الدخول يعمل
□ SSL مفعّل
□ كلمة المرور متغيّرة
□ Backup مفعّل

✅ All done!
```

---

**المدة الإجمالية**: 50 دقيقة  
**المستوى**: سهل (خطوة بخطوة)  
**النتيجة**: موقع حي على الإنترنت! 🎊
