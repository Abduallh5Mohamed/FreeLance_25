"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const db_1 = require("../db");
const whatsapp_free_1 = require("../services/whatsapp-free");
const router = (0, express_1.Router)();
// Get all subscription requests
router.get('/', async (req, res) => {
    try {
        const { status } = req.query;
        let sql = 'SELECT * FROM subscription_requests WHERE 1=1';
        const params = [];
        if (status) {
            sql += ' AND status = ?';
            params.push(status);
        }
        sql += ' ORDER BY created_at DESC';
        const requests = await (0, db_1.query)(sql, params);
        res.json(requests);
    }
    catch (error) {
        console.error('Error fetching subscription requests:', error);
        res.status(500).json({ error: 'Failed to fetch subscription requests' });
    }
});
// Create new subscription request
router.post('/', async (req, res) => {
    try {
        const { student_name, phone, guardian_phone, grade_id, grade_name, group_id, group_name, amount, notes, receipt_image_url } = req.body;
        if (!student_name || !phone) {
            return res.status(400).json({ error: 'Student name and phone are required' });
        }
        // Generate UUID for the new request
        const { randomUUID } = await Promise.resolve().then(() => __importStar(require('crypto')));
        const requestId = randomUUID();
        await (0, db_1.execute)(`INSERT INTO subscription_requests 
       (id, student_name, phone, guardian_phone, grade_id, grade_name, group_id, group_name, amount, notes, receipt_image_url, status) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')`, [requestId, student_name, phone, guardian_phone || null, grade_id || null, grade_name || null, group_id || null, group_name || null, amount || null, notes || null, receipt_image_url || null]);
        res.status(201).json({
            message: 'Subscription request created successfully',
            id: requestId
        });
    }
    catch (error) {
        console.error('Error creating subscription request:', error);
        res.status(500).json({ error: 'Failed to create subscription request' });
    }
});
// Approve subscription request
router.post('/:id/approve', async (req, res) => {
    try {
        const { id } = req.params;
        const requests = await (0, db_1.query)('SELECT * FROM subscription_requests WHERE id = ?', [id]);
        if (!Array.isArray(requests) || requests.length === 0) {
            return res.status(404).json({ error: 'Subscription request not found' });
        }
        const request = requests[0];
        if (request.status !== 'pending') {
            return res.status(400).json({ error: 'Request already processed' });
        }
        // Check if student already exists
        const existingStudents = await (0, db_1.query)('SELECT id FROM students WHERE phone = ?', [request.phone]);
        // Validate grade_id and group_id before inserting
        let validGradeId = null;
        let validGroupId = null;
        if (request.grade_id) {
            const gradeCheck = await (0, db_1.query)('SELECT id FROM grades WHERE id = ?', [request.grade_id]);
            if (Array.isArray(gradeCheck) && gradeCheck.length > 0) {
                validGradeId = request.grade_id;
            }
        }
        if (request.group_id) {
            const groupCheck = await (0, db_1.query)('SELECT id FROM `groups` WHERE id = ?', [request.group_id]);
            if (Array.isArray(groupCheck) && groupCheck.length > 0) {
                validGroupId = request.group_id;
            }
        }
        let studentId;
        if (!Array.isArray(existingStudents) || existingStudents.length === 0) {
            // Add student to students table (online)
            const result = await (0, db_1.execute)(`INSERT INTO students 
         (name, phone, grade_id, group_id, is_offline, approval_status) 
         VALUES (?, ?, ?, ?, FALSE, 'approved')`, [request.student_name, request.phone, validGradeId, validGroupId]);
            studentId = result.insertId;
        }
        else {
            studentId = existingStudents[0].id;
        }
        // Add fee record with paid_amount = amount (since they already paid)
        await (0, db_1.execute)(`INSERT INTO student_fees 
       (student_name, phone, grade_id, grade_name, group_id, group_name, amount, paid_amount, status, is_offline, payment_method, notes, receipt_image_url, payment_date) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'paid', FALSE, 'online', ?, ?, NOW())`, [request.student_name, request.phone, validGradeId, request.grade_name, validGroupId, request.group_name, request.amount || 0, request.amount || 0, request.notes, request.receipt_image_url]);
        // Update request status
        await (0, db_1.execute)('UPDATE subscription_requests SET status = ?, updated_at = NOW() WHERE id = ?', ['approved', id]);
        // Send WhatsApp message to guardian if guardian_phone exists
        let whatsappSent = false;
        let whatsappLink = '';
        if (request.guardian_phone) {
            try {
                const result = await (0, whatsapp_free_1.sendSubscriptionApprovalNotification)(String(request.guardian_phone), String(request.student_name), Number(request.amount), String(request.grade_name || 'غير محدد'), String(request.group_name || 'غير محدد'));
                whatsappSent = result.success;
                whatsappLink = result.whatsappLink || '';
                if (result.success) {
                    console.log(`✅ WhatsApp link generated for ${request.guardian_phone}`);
                    console.log(`🔗 Link: ${result.whatsappLink}`);
                }
                else {
                    console.error(`❌ Failed to generate WhatsApp link: ${result.error}`);
                }
            }
            catch (whatsappError) {
                console.error('Error sending WhatsApp message:', whatsappError);
                // Don't fail the approval if WhatsApp fails
            }
        }
        res.json({
            message: 'Subscription request approved successfully',
            whatsapp_sent: whatsappSent,
            whatsapp_link: whatsappLink
        });
    }
    catch (error) {
        console.error('Error approving subscription request:', error);
        res.status(500).json({ error: 'Failed to approve subscription request' });
    }
});
// Reject subscription request
router.post('/:id/reject', async (req, res) => {
    try {
        const { id } = req.params;
        const { rejection_reason } = req.body;
        if (!rejection_reason) {
            return res.status(400).json({ error: 'Rejection reason is required' });
        }
        const requests = await (0, db_1.query)('SELECT * FROM subscription_requests WHERE id = ?', [id]);
        if (!Array.isArray(requests) || requests.length === 0) {
            return res.status(404).json({ error: 'Subscription request not found' });
        }
        const request = requests[0];
        if (request.status !== 'pending') {
            return res.status(400).json({ error: 'Request already processed' });
        }
        await (0, db_1.execute)('UPDATE subscription_requests SET status = ?, rejection_reason = ?, updated_at = NOW() WHERE id = ?', ['rejected', rejection_reason, id]);
        res.json({ message: 'Subscription request rejected successfully' });
    }
    catch (error) {
        console.error('Error rejecting subscription request:', error);
        res.status(500).json({ error: 'Failed to reject subscription request' });
    }
});
// Delete subscription request (cleanup)
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await (0, db_1.execute)('DELETE FROM subscription_requests WHERE id = ?', [id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Subscription request not found' });
        }
        res.json({ message: 'Subscription request deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting subscription request:', error);
        res.status(500).json({ error: 'Failed to delete subscription request' });
    }
});
// Bulk delete approved requests by month
router.delete('/cleanup/month', async (req, res) => {
    try {
        const { month, year } = req.query;
        if (!month || !year) {
            return res.status(400).json({ error: 'Month and year are required' });
        }
        const result = await (0, db_1.execute)('DELETE FROM subscription_requests WHERE status = ? AND MONTH(updated_at) = ? AND YEAR(updated_at) = ?', ['approved', month, year]);
        res.json({
            message: 'Approved requests cleaned up successfully',
            deletedCount: result.affectedRows
        });
    }
    catch (error) {
        console.error('Error cleaning up requests:', error);
        res.status(500).json({ error: 'Failed to cleanup requests' });
    }
});
exports.default = router;
